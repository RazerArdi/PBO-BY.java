package Modul4CODELAB;
import Modul4CODELAB.Kuda;
import Modul4CODELAB.Anjing;

interface IKarnivora {
    void tampilMakanan();
}
